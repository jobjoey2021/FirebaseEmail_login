# Firebase Authentication 第三方登入 – Google、FB

Demo：[Version 8](https://letswritetw.github.io/letswrite-firebase-auth-google-fb/)、[Version 9](https://letswritetw.github.io/letswrite-firebase-auth-google-fb/v9.html)

筆記文：[Let's Write](https://letswrite.tw/firebase-auth-google-fb/)
