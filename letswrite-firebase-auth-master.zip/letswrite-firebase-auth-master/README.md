# 用 Firebase Authentication 做一套簡易會員系統 - 電子郵件 密碼

Demo：[demo](https://letswritetw.github.io/letswrite-firebase-auth/)

筆記文：[Let's Write](https://letswrite.tw/firebase-auth/)
